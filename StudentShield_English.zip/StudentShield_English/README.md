# StudentShield — English Website Prototype

A responsive, English-language StudentShield website prototype with a blue and green visual theme.

## Website sections
- Risk Lookup: phone numbers, rental listings, company/job offers, and bank account identifiers
- Demo results with green, yellow, red, and neutral states
- How It Works: a clear explanation of the intended verification workflow
- Report a Scam: form validation and evidence-file selection
- Safety Guide and Frequently Asked Questions
- Responsive layouts for desktop and mobile screens

## Run locally
Open `index.html` in a modern web browser. No package installation is required.

## Prototype limitations
This is a front-end demonstration only. It is not connected to a live risk database. All lookup entries are fictional examples. The report form does not upload, store, or transmit report information or evidence. Any displayed reference number is generated locally for demonstration purposes only.

## Before a production launch
A real service requires a secure backend and database, authentication and role-based access, secure file upload and malware scanning, encryption, human moderation, audit trails, privacy and data-retention controls, a correction and appeal process, abuse prevention, and legal review for the launch jurisdiction. Do not label a person or organisation as safe solely because no report was found.

## Static hosting and custom domains
Upload `index.html` to a static hosting provider. Configure any custom domain and its DNS records in that provider's dashboard. Editing this HTML file alone does not activate a custom domain.
